# MaterialDesign-Webfont
Bower Dist for Material Design Webfont. This includes the Stock and Community icons in a single webfont collection.

## Learn More

https://github.com/Templarian/MaterialDesign
